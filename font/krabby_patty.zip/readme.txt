Krabby Patty v1.0
by Seil Weiss

Krabby Patty is a remake of the font used in the SpongeBob SquarePants logo and other areas of the TV show.

Includes Latin upper/lower case letters, some ASCII characters, and numbers. Most glyphs were tediously ripped from image files of the SBSP:OKP PC game.

Questions/comments? Email me at seilweiss@gmail.com

Enjoy!

FOR PERSONAL USE ONLY